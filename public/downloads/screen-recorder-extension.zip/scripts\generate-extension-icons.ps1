$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Drawing

function New-Color {
  param(
    [Parameter(Mandatory = $true)]
    [string] $Hex,

    [int] $Alpha = 255
  )

  $baseColor = [System.Drawing.ColorTranslator]::FromHtml($Hex)
  return [System.Drawing.Color]::FromArgb($Alpha, $baseColor.R, $baseColor.G, $baseColor.B)
}

function New-RoundedRectPath {
  param(
    [float] $X,
    [float] $Y,
    [float] $Width,
    [float] $Height,
    [float] $Radius
  )

  $path = New-Object System.Drawing.Drawing2D.GraphicsPath
  if ($Radius -le 0) {
    $path.AddRectangle([System.Drawing.RectangleF]::new($X, $Y, $Width, $Height))
    return $path
  }

  $diameter = $Radius * 2
  $path.AddArc($X, $Y, $diameter, $diameter, 180, 90)
  $path.AddArc($X + $Width - $diameter, $Y, $diameter, $diameter, 270, 90)
  $path.AddArc($X + $Width - $diameter, $Y + $Height - $diameter, $diameter, $diameter, 0, 90)
  $path.AddArc($X, $Y + $Height - $diameter, $diameter, $diameter, 90, 90)
  $path.CloseFigure()
  return $path
}

function Write-RecorderIcon {
  param(
    [int] $Size,

    [Parameter(Mandatory = $true)]
    [string] $OutputPath
  )

  $bitmap = New-Object System.Drawing.Bitmap($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  try {
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    try {
      $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
      $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
      $graphics.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
      $graphics.Clear([System.Drawing.Color]::Transparent)

      $canvas = [float] $Size
      $margin = [math]::Round($canvas * 0.08, 2)
      if ($Size -le 24) {
        $margin = 1
      }

      $backgroundX = $margin
      $backgroundY = $margin
      $backgroundWidth = $canvas - (2 * $margin)
      $backgroundHeight = $canvas - (2 * $margin)
      $backgroundRadius = [math]::Round($canvas * 0.2, 2)

      if ($Size -ge 32) {
        $shadowOffset = [math]::Round($canvas * 0.03, 2)
        $shadowPath = New-RoundedRectPath -X $backgroundX -Y ($backgroundY + $shadowOffset) -Width $backgroundWidth -Height $backgroundHeight -Radius $backgroundRadius
        try {
          $shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(55, 3, 13, 34))
          try {
            $graphics.FillPath($shadowBrush, $shadowPath)
          }
          finally {
            $shadowBrush.Dispose()
          }
        }
        finally {
          $shadowPath.Dispose()
        }
      }

      $backgroundPath = New-RoundedRectPath -X $backgroundX -Y $backgroundY -Width $backgroundWidth -Height $backgroundHeight -Radius $backgroundRadius
      try {
        $backgroundRect = [System.Drawing.RectangleF]::new($backgroundX, $backgroundY, $backgroundWidth, $backgroundHeight)
        $backgroundBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $backgroundRect,
          (New-Color -Hex '#091937'),
          (New-Color -Hex '#1E63EA'),
          45.0
        )

        try {
          $graphics.FillPath($backgroundBrush, $backgroundPath)
        }
        finally {
          $backgroundBrush.Dispose()
        }

        if ($Size -ge 24) {
          $highlightBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(34, 255, 255, 255))
          try {
            $graphics.FillEllipse(
              $highlightBrush,
              $backgroundX + ($backgroundWidth * 0.08),
              $backgroundY + ($backgroundHeight * 0.06),
              $backgroundWidth * 0.58,
              $backgroundHeight * 0.32
            )
          }
          finally {
            $highlightBrush.Dispose()
          }
        }

        $backgroundOutline = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(42, 255, 255, 255), [math]::Max(1.0, [math]::Round($canvas * 0.028, 2)))
        try {
          $graphics.DrawPath($backgroundOutline, $backgroundPath)
        }
        finally {
          $backgroundOutline.Dispose()
        }
      }
      finally {
        $backgroundPath.Dispose()
      }

      $screenX = [math]::Round($canvas * 0.21, 2)
      $screenY = [math]::Round($canvas * 0.22, 2)
      $screenWidth = [math]::Round($canvas * 0.58, 2)
      $screenHeight = [math]::Round($canvas * 0.34, 2)
      $screenRadius = [math]::Round($canvas * 0.09, 2)
      $screenPath = New-RoundedRectPath -X $screenX -Y $screenY -Width $screenWidth -Height $screenHeight -Radius $screenRadius

      try {
        $screenFill = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(22, 255, 255, 255))
        try {
          $graphics.FillPath($screenFill, $screenPath)
        }
        finally {
          $screenFill.Dispose()
        }

        $screenStrokeWidth = [math]::Max(1.2, [math]::Round($canvas * 0.055, 2))
        if ($Size -le 16) {
          $screenStrokeWidth = 1.3
        }

        $screenPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(248, 255, 255, 255), $screenStrokeWidth)
        $screenPen.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round

        try {
          $graphics.DrawPath($screenPen, $screenPath)
        }
        finally {
          $screenPen.Dispose()
        }
      }
      finally {
        $screenPath.Dispose()
      }

      if ($Size -ge 24) {
        $standPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(170, 255, 255, 255), [math]::Max(1.0, [math]::Round($canvas * 0.03, 2)))
        $standPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
        $standPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
        try {
          $standWidth = [math]::Round($canvas * 0.18, 2)
          $standY = [math]::Round($canvas * 0.58, 2)
          $graphics.DrawLine($standPen, ($canvas - $standWidth) / 2, $standY, ($canvas + $standWidth) / 2, $standY)
        }
        finally {
          $standPen.Dispose()
        }
      }

      $ringDiameter = [math]::Round($canvas * 0.24, 2)
      $ringX = [math]::Round(($canvas - $ringDiameter) / 2, 2)
      $ringY = [math]::Round($canvas * 0.61, 2)
      $ringStrokeWidth = [math]::Max(1.2, [math]::Round($canvas * 0.045, 2))
      $ringPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(235, 255, 255, 255), $ringStrokeWidth)

      try {
        $graphics.DrawEllipse($ringPen, $ringX, $ringY, $ringDiameter, $ringDiameter)
      }
      finally {
        $ringPen.Dispose()
      }

      $recordInset = [math]::Max(1.0, [math]::Round($canvas * 0.03, 2))
      $recordBrush = New-Object System.Drawing.SolidBrush((New-Color -Hex '#FF5A5F'))
      try {
        $graphics.FillEllipse($recordBrush, $ringX + $recordInset, $ringY + $recordInset, $ringDiameter - (2 * $recordInset), $ringDiameter - (2 * $recordInset))
      }
      finally {
        $recordBrush.Dispose()
      }

      if ($Size -ge 24) {
        $shineBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(72, 255, 255, 255))
        try {
          $graphics.FillEllipse(
            $shineBrush,
            $ringX + $recordInset + ($ringDiameter * 0.16),
            $ringY + $recordInset + ($ringDiameter * 0.12),
            $ringDiameter * 0.22,
            $ringDiameter * 0.16
          )
        }
        finally {
          $shineBrush.Dispose()
        }
      }

      $bitmap.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)
    }
    finally {
      $graphics.Dispose()
    }
  }
  finally {
    $bitmap.Dispose()
  }
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$iconsDirectory = Join-Path $repoRoot 'icons'
$iconSizes = 16, 32, 48, 128

if (-not (Test-Path $iconsDirectory)) {
  New-Item -ItemType Directory -Path $iconsDirectory | Out-Null
}

foreach ($iconSize in $iconSizes) {
  $targetPath = Join-Path $iconsDirectory "icon-$iconSize.png"
  Write-RecorderIcon -Size $iconSize -OutputPath $targetPath
  Write-Host "Generated $targetPath"
}

