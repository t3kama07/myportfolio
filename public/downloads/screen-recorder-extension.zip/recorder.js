const DEFAULT_OPTIONS = {
  micEnabled: false,
  tabAudioEnabled: false
};

const startBtn = document.getElementById('startBtn');
const pauseBtn = document.getElementById('pauseBtn');
const stopBtn = document.getElementById('stopBtn');
const timerText = document.getElementById('timerText');
const micOption = document.getElementById('micOption');
const tabAudioOption = document.getElementById('tabAudioOption');
const microphoneToggle = document.getElementById('microphoneToggle');
const tabAudioToggle = document.getElementById('tabAudioToggle');
const micStatus = document.getElementById('micStatus');
const tabAudioStatus = document.getElementById('tabAudioStatus');
const statusText = document.getElementById('statusText');
const preview = document.getElementById('preview');
const downloadLink = document.getElementById('downloadLink');
const emptyState = document.getElementById('emptyState');

let recorderOptions = { ...DEFAULT_OPTIONS };
let mediaRecorder;
let displayStream;
let micStream;
let recordingStream;
let audioContext;
let mixedAudioSources = [];
let recordedChunks = [];
let previewUrl = '';
let ignoreTrackEnded = false;
let timerIntervalId;
let elapsedSeconds = 0;

function readOptions() {
  return new Promise((resolve) => {
    if (!chrome.storage || !chrome.storage.local) {
      resolve({ ...DEFAULT_OPTIONS });
      return;
    }

    chrome.storage.local.get({ recorderOptions: DEFAULT_OPTIONS }, (result) => {
      resolve({ ...DEFAULT_OPTIONS, ...(result.recorderOptions || {}) });
    });
  });
}

function writeOptions(options) {
  return new Promise((resolve) => {
    if (!chrome.storage || !chrome.storage.local) {
      resolve();
      return;
    }

    chrome.storage.local.set({ recorderOptions: options }, () => resolve());
  });
}

function formatDuration(totalSeconds) {
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
  const seconds = String(totalSeconds % 60).padStart(2, '0');
  return `${minutes}:${seconds}`;
}

function updateTimerDisplay() {
  timerText.textContent = formatDuration(elapsedSeconds);
}

function resetTimer() {
  elapsedSeconds = 0;
  updateTimerDisplay();
}

function startTimer() {
  stopTimer();
  timerIntervalId = window.setInterval(() => {
    elapsedSeconds += 1;
    updateTimerDisplay();
  }, 1000);
}

function stopTimer() {
  if (!timerIntervalId) {
    return;
  }

  window.clearInterval(timerIntervalId);
  timerIntervalId = undefined;
}

function setStatus(message, state = 'idle') {
  statusText.textContent = message;
  statusText.dataset.state = state;
}

function setControls({
  startDisabled,
  pauseDisabled,
  stopDisabled,
  pauseLabel = 'Pause'
}) {
  startBtn.disabled = startDisabled;
  pauseBtn.disabled = pauseDisabled;
  stopBtn.disabled = stopDisabled;
  pauseBtn.textContent = pauseLabel;
  setOptionControlsDisabled(startDisabled);
}

function clearPreview() {
  if (previewUrl) {
    URL.revokeObjectURL(previewUrl);
    previewUrl = '';
  }

  preview.pause();
  preview.removeAttribute('src');
  preview.hidden = true;
  downloadLink.hidden = true;
  downloadLink.removeAttribute('href');
  emptyState.hidden = false;
}

function renderOptionStatus() {
  microphoneToggle.checked = recorderOptions.micEnabled;
  tabAudioToggle.checked = recorderOptions.tabAudioEnabled;

  micStatus.textContent = recorderOptions.micEnabled ? 'Microphone On' : 'Microphone Off';
  micOption.dataset.active = recorderOptions.micEnabled ? 'true' : 'false';

  tabAudioStatus.textContent = recorderOptions.tabAudioEnabled ? 'Tab Audio On' : 'Tab Audio Off';
  tabAudioOption.dataset.active = recorderOptions.tabAudioEnabled ? 'true' : 'false';
}

function setOptionControlsDisabled(disabled) {
  microphoneToggle.disabled = disabled;
  tabAudioToggle.disabled = disabled;
  micOption.dataset.disabled = disabled ? 'true' : 'false';
  tabAudioOption.dataset.disabled = disabled ? 'true' : 'false';
}

function getCurrentOptions() {
  return {
    micEnabled: microphoneToggle.checked,
    tabAudioEnabled: tabAudioToggle.checked
  };
}

async function saveCurrentOptions() {
  recorderOptions = { ...DEFAULT_OPTIONS, ...getCurrentOptions() };
  renderOptionStatus();
  await writeOptions(recorderOptions);

  if (!mediaRecorder || mediaRecorder.state === 'inactive') {
    setStatus('Recording options updated. Press Start Recording when you are ready.', 'idle');
  }
}

function buildRecorder(streamToRecord) {
  const preferredMimeTypes = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm'
  ];

  const mimeType = preferredMimeTypes.find((candidate) => MediaRecorder.isTypeSupported(candidate));
  return mimeType ? new MediaRecorder(streamToRecord, { mimeType }) : new MediaRecorder(streamToRecord);
}

async function buildRecordingStream() {
  displayStream = await navigator.mediaDevices.getDisplayMedia({
    video: {
      frameRate: {
        ideal: 30,
        max: 30
      }
    },
    audio: recorderOptions.tabAudioEnabled
  });

  let micError;

  if (recorderOptions.micEnabled) {
    try {
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          autoGainControl: true,
          echoCancellation: true,
          noiseSuppression: true
        }
      });
    } catch (error) {
      micError = error;
      micStream = undefined;
    }
  }

  const videoTracks = displayStream.getVideoTracks();
  if (!videoTracks.length) {
    throw new Error('Chrome did not provide a video track for this recording.');
  }

  const displayAudioTracks = displayStream.getAudioTracks();
  const micAudioTracks = micStream ? micStream.getAudioTracks() : [];
  const tracks = [...videoTracks];

  if (displayAudioTracks.length || micAudioTracks.length) {
    // Mix any enabled audio sources into one track so the recording stays portable.
    audioContext = new AudioContext();
    mixedAudioSources = [];

    if (audioContext.state === 'suspended') {
      await audioContext.resume().catch(() => {});
    }

    const destination = audioContext.createMediaStreamDestination();

    if (displayAudioTracks.length) {
      const displaySource = audioContext.createMediaStreamSource(new MediaStream(displayAudioTracks));
      displaySource.connect(destination);
      mixedAudioSources.push(displaySource);
    }

    if (micAudioTracks.length) {
      const microphoneSource = audioContext.createMediaStreamSource(new MediaStream(micAudioTracks));
      microphoneSource.connect(destination);
      mixedAudioSources.push(microphoneSource);
    }

    tracks.push(...destination.stream.getAudioTracks());
  }

  recordingStream = new MediaStream(tracks);

  return {
    hasDisplayAudio: displayAudioTracks.length > 0,
    hasMicAudio: micAudioTracks.length > 0,
    micError
  };
}

function stopAllStreams() {
  ignoreTrackEnded = true;

  if (recordingStream) {
    recordingStream.getTracks().forEach((track) => track.stop());
    recordingStream = undefined;
  }

  if (displayStream) {
    displayStream.getTracks().forEach((track) => track.stop());
    displayStream = undefined;
  }

  if (micStream) {
    micStream.getTracks().forEach((track) => track.stop());
    micStream = undefined;
  }

  mixedAudioSources = [];

  if (audioContext) {
    audioContext.close().catch(() => {});
    audioContext = undefined;
  }
}

function autoDownloadRecording() {
  downloadLink.click();
}

function finalizeRecording() {
  stopTimer();

  const finalDuration = formatDuration(elapsedSeconds);
  const blobType = recordedChunks[0]?.type || 'video/webm';
  const recording = new Blob(recordedChunks, { type: blobType });

  if (!recording.size) {
    setStatus('Recording stopped, but no video data was captured.', 'error');
    setControls({ startDisabled: false, pauseDisabled: true, stopDisabled: true });
    resetTimer();
    stopAllStreams();
    mediaRecorder = undefined;
    return;
  }

  previewUrl = URL.createObjectURL(recording);
  preview.src = previewUrl;
  preview.hidden = false;
  preview.play().catch(() => {});

  downloadLink.href = previewUrl;
  downloadLink.download = 'recording.webm';
  downloadLink.hidden = false;
  emptyState.hidden = true;
  autoDownloadRecording();

  setStatus(`Recording saved after ${finalDuration}. The download should begin automatically.`, 'idle');
  setControls({ startDisabled: false, pauseDisabled: true, stopDisabled: true });
  resetTimer();
  stopAllStreams();
  mediaRecorder = undefined;
}

function getStartMessage({ hasDisplayAudio, hasMicAudio, micError }) {
  const notes = [];

  if (recorderOptions.tabAudioEnabled && !hasDisplayAudio) {
    notes.push('Tab audio was not available for the share selection you chose.');
  }

  if (recorderOptions.micEnabled && !hasMicAudio) {
    notes.push(
      micError
        ? 'Microphone access was blocked, so this recording will continue without your microphone.'
        : 'Microphone audio was not added to this recording.'
    );
  }

  return notes.length
    ? `Recording in progress. ${notes.join(' ')}`
    : 'Recording in progress.';
}

async function startRecording() {
  clearPreview();
  recordedChunks = [];
  resetTimer();
  ignoreTrackEnded = false;
  setStatus('Waiting for Chrome to confirm what you want to share...', 'idle');
  setControls({ startDisabled: true, pauseDisabled: true, stopDisabled: true });

  try {
    const recordingSetup = await buildRecordingStream();
    const videoTrack = displayStream.getVideoTracks()[0];

    if (videoTrack) {
      videoTrack.addEventListener(
        'ended',
        () => {
          if (ignoreTrackEnded) {
            return;
          }

          if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
          } else {
            setStatus('Screen sharing ended.', 'idle');
            setControls({ startDisabled: false, pauseDisabled: true, stopDisabled: true });
            resetTimer();
            stopAllStreams();
          }
        },
        { once: true }
      );
    }

    mediaRecorder = buildRecorder(recordingStream);
    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        recordedChunks.push(event.data);
      }
    };

    mediaRecorder.onstop = finalizeRecording;
    mediaRecorder.onerror = (event) => {
      const message = event.error?.message || 'Unknown recording error.';
      stopTimer();
      setStatus(`Recording failed: ${message}`, 'error');
      setControls({ startDisabled: false, pauseDisabled: true, stopDisabled: true });
      resetTimer();
      stopAllStreams();
      mediaRecorder = undefined;
    };

    mediaRecorder.start(250);
    startTimer();
    setStatus(getStartMessage(recordingSetup), 'recording');
    setControls({ startDisabled: true, pauseDisabled: false, stopDisabled: false });
  } catch (error) {
    const wasCancelled = error && (error.name === 'NotAllowedError' || error.name === 'AbortError');
    setStatus(
      wasCancelled
        ? 'Screen sharing was canceled before recording started.'
        : `Could not start recording: ${error.message}`,
      wasCancelled ? 'idle' : 'error'
    );
    setControls({ startDisabled: false, pauseDisabled: true, stopDisabled: true });
    resetTimer();
    stopAllStreams();
    mediaRecorder = undefined;
  }
}

function togglePauseResume() {
  if (!mediaRecorder || mediaRecorder.state === 'inactive') {
    return;
  }

  if (mediaRecorder.state === 'recording') {
    mediaRecorder.pause();
    stopTimer();
    setStatus('Recording paused. Press Resume when you are ready to continue.', 'paused');
    setControls({
      startDisabled: true,
      pauseDisabled: false,
      stopDisabled: false,
      pauseLabel: 'Resume'
    });
    return;
  }

  if (mediaRecorder.state === 'paused') {
    mediaRecorder.resume();
    startTimer();
    setStatus('Recording in progress.', 'recording');
    setControls({
      startDisabled: true,
      pauseDisabled: false,
      stopDisabled: false,
      pauseLabel: 'Pause'
    });
  }
}

function stopRecording() {
  if (!mediaRecorder || mediaRecorder.state === 'inactive') {
    return;
  }

  stopTimer();
  stopBtn.disabled = true;
  pauseBtn.disabled = true;
  setStatus('Finishing the recording...', 'idle');
  mediaRecorder.stop();
}

async function initializeRecorder() {
  recorderOptions = await readOptions();
  renderOptionStatus();
  resetTimer();
  clearPreview();
  setControls({ startDisabled: false, pauseDisabled: true, stopDisabled: true });
  setStatus('Choose your audio options here or in the extension popup, then press Start Recording.', 'idle');
}

startBtn.addEventListener('click', startRecording);
pauseBtn.addEventListener('click', togglePauseResume);
stopBtn.addEventListener('click', stopRecording);
microphoneToggle.addEventListener('change', saveCurrentOptions);
tabAudioToggle.addEventListener('change', saveCurrentOptions);

window.addEventListener('beforeunload', () => {
  stopTimer();
  stopAllStreams();

  if (previewUrl) {
    URL.revokeObjectURL(previewUrl);
  }
});

initializeRecorder();
