// Background script placeholder (required for manifest v3)
