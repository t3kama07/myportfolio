const DEFAULT_OPTIONS = {
  micEnabled: false,
  tabAudioEnabled: false
};

const microphoneToggle = document.getElementById('microphoneToggle');
const tabAudioToggle = document.getElementById('tabAudioToggle');
const openRecorderBtn = document.getElementById('openRecorderBtn');

function readOptions() {
  return new Promise((resolve) => {
    if (!chrome.storage || !chrome.storage.local) {
      resolve({ ...DEFAULT_OPTIONS });
      return;
    }

    chrome.storage.local.get({ recorderOptions: DEFAULT_OPTIONS }, (result) => {
      resolve({ ...DEFAULT_OPTIONS, ...(result.recorderOptions || {}) });
    });
  });
}

function writeOptions(options) {
  return new Promise((resolve) => {
    if (!chrome.storage || !chrome.storage.local) {
      resolve();
      return;
    }

    chrome.storage.local.set({ recorderOptions: options }, () => resolve());
  });
}

function getCurrentOptions() {
  return {
    micEnabled: microphoneToggle.checked,
    tabAudioEnabled: tabAudioToggle.checked
  };
}

async function saveCurrentOptions() {
  await writeOptions(getCurrentOptions());
}

async function initializePopup() {
  const savedOptions = await readOptions();
  microphoneToggle.checked = savedOptions.micEnabled;
  tabAudioToggle.checked = savedOptions.tabAudioEnabled;
}

microphoneToggle.addEventListener('change', saveCurrentOptions);
tabAudioToggle.addEventListener('change', saveCurrentOptions);

openRecorderBtn.addEventListener('click', async () => {
  await saveCurrentOptions();
  const recorderUrl = chrome.runtime.getURL('recorder.html');
  window.open(recorderUrl, '_blank', 'noopener');
  window.close();
});

initializePopup();
